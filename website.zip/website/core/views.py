from django.shortcuts import render
from core.models import Post
from django.views.generic import CreateView
import random

# Create your views here.

def splash(request): #Home Page
    rand_int = random.randint(1, 3)
    pic_one = "/media/images/group_1.jpg"
    pic_two = "/media/images/group_2.jpg"
    pic_three = "/media/images/group_3.jpg"
    if rand_int == 1:
        return render(request, "splash.html", {"picture": pic_one})
    elif rand_int == 2:
        return render(request, "splash.html", {"picture": pic_two})
    else:
        return render(request, "splash.html", {"picture": pic_three})

def alpha_chi(request): #Every Pledge Class
    return render(request, "alpha-chi.html", {})

def alpha_phi(request):
    return render(request, "alpha-phi.html", {})

def alpha_upsilon(request):
    return render(request, "alpha-upsilon.html", {})

def alpha_tau(request):
    return render(request, "alpha-tau.html", {})

def alpha_sigma(request):
    return render(request, "alpha-sigma.html", {})

def alpha_rho(request):
    return render(request, "alpha-rho.html", {})

def alpha_xi(request):
    return render(request, "alpha-xi.html", {})

def alpha_omicron(request):
    return render(request, "alpha-omicron.html", {})

def alpha_pi(request):
    return render(request, "alpha-pi.html", {})

def blogs(request): #All blogs
    posts = Post.objects.all()
    return render(request, "blogs.html", {"post_list": reversed(posts)})

def blog_view(request, id): #Each individual blog with a unique PK
    post = Post.objects.get(pk=id)
    return render(request, "blog_article.html", {"post": post})
    
class AddPostView(CreateView): # Wanted to try this out
    model = Post
    template_name = "write_blog.html"
    fields = '__all__'

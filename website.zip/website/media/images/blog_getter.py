import os
from selenium import webdriver
import requests
from selenium.webdriver.chrome.options import Options
options = Options()
options.headless = False #See Headless Brwoser

class PictureGetter:
    def get_pictures(self):
        # CHANGE THIS ABSOLUTE PATH
        driver = webdriver.Chrome('/Users/lumingwang/Desktop/website/media/images/chromedriver', options=options)

        url = "https://www.instagram.com/akpsiupenn/"
        driver.get(url)
        images = driver.find_elements_by_class_name("_bz0w")
        images_href = []
        for img in images: #Get links of Instagram Pictures
            href = img.find_element_by_tag_name("a").get_attribute("href")
            images_href.append(href)
            
        for number, href in enumerate(images_href): #For each link grab image
            if number == 10:
                break
            driver.get(href)

            img_src = driver.find_element_by_xpath('//div/img').get_attribute("src")

            r = requests.get(img_src)
            filename = f'instagram-{number}.jpg'
            
            with open(filename, 'wb') as fp:
                fp.write(r.content) #Save to files
                fp.flush()
        driver.quit()
                
    def __repr__(self): #Magic Method 2
        count = 0 #Delete all files
        while os.path.exists("instagram-" + str(count) + ".jpg"):
            os.remove("instagram-" + str(count) + ".jpg")
            count += 1
        return ""

getter = PictureGetter()

#getter.get_pictures() #Get pictures
repr(getter) #Delete pictures



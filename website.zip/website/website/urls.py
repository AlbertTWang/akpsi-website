"""website URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from core.views import splash, blogs, blog_view, AddPostView
from core.views import alpha_chi, alpha_phi, alpha_upsilon, alpha_tau, alpha_sigma, alpha_rho, alpha_xi, alpha_omicron, alpha_pi

urlpatterns = [ #All URLs
    path('admin/', admin.site.urls),
    path('djrichtextfield/', include('djrichtextfield.urls')),
    path('', splash, name='splash'),
    path('alpha-chi', alpha_chi, name='alpha-chi'),
    path('alpha-phi', alpha_phi, name='alpha-phi'),
    path('alpha-upsilon', alpha_upsilon, name='alpha-upsilon'),
    path('alpha-tau', alpha_tau, name='alpha-tau'),
    path('alpha-sigma', alpha_sigma, name='alpha-sigma'),
    path('alpha-rho', alpha_rho, name='alpha-rho'),
    path('alpha-xi', alpha_xi, name='alpha-xi'),
    path('alpha-omicron', alpha_omicron, name='alpha-omicron'),
    path('alpha-pi', alpha_pi, name='alpha-pi'),
    path('blogs', blogs, name='blogs'),
    path('blogs/<str:id>', blog_view, name='blog_view'),
    path('write_blog', AddPostView.as_view(), name='write_blog'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) #Images

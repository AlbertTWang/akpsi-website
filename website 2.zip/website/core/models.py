from django.db import models
from django.contrib.auth.models import User
from djrichtextfield.models import RichTextField
from django.urls import reverse

# Create your models here.

class Post(models.Model): #Post class and its fields
    category = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    header_image = models.ImageField(null=True, blank=True, upload_to="images/")
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    body = models.TextField()
    post_date = models.DateField(auto_now_add=True)

    def __str__(self): #Magic Method
        return self.title + ' | ' + str(self.author)
    
    def get_absolute_url(self): #KISS (Learned from online, makes life easy)
        return reverse('blog_view', args=[str(self.id)])

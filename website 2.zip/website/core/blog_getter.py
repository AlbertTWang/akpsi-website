from selenium import webdriver
import requests
from selenium.webdriver.chrome.options import Options
options = Options()
options.headless = False #See the program working

#Absolute Path: MUST CHANGE if want to test yourself
driver = webdriver.Chrome('/Users/lumingwang/Desktop/website/media/images/chromedriver', options=options)

url = "https://www.instagram.com/akpsiupenn/" #Instagram URL
driver.get(url)
images = driver.find_elements_by_class_name("_bz0w")
images_href = [] #Get href of each image on the page
for img in images:
    href = img.find_element_by_tag_name("a").get_attribute("href")
    images_href.append(href)

for number, href in enumerate(images_href):
    if number == 10: #Get max 10 photos
        break
    
    driver.get(href) #Click the link of each image
    img_src = driver.find_element_by_xpath('//div/img').get_attribute("src")
    r = requests.get(img_src) #Grab Image
    filename = 'instagram' + str(number) + '.jpg'
    with open(filename, 'wb') as fp: #Save to files
        fp.write(r.content)

driver.quit()

